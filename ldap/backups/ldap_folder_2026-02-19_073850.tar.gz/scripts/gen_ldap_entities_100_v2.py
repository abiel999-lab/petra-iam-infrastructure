\
#!/usr/bin/env python3
"""
Petra IAM - Generate 100 LDAP entities + rollback (revert) LDIFs

✅ Requirements you asked:
1) 100 entries total:
   - 50 Indonesian human names (first + last)
   - 50 non-human 2-word names (product/division/company-style)

2) Attributes used (exactly like your example):
   dn, objectClass (inetOrgPerson + petraPerson),
   uid, cn, sn, givenName, displayName,
   mail,
   mailAlternateAddress (MULTI-VALUE, MUST ALWAYS contain 4 values),
   petraUUID, petraAffiliation, petraAccountStatus, studentNumber (students only),
   userPassword (SSHA) -> written as base64 (double-colon) like your sample

3) mail:
   - domain is randomized from: john.petra.ac.id / peter.petra.ac.id / petra.petra.ac.id

4) mailAlternateAddress MUST ALWAYS include:
   - <handle>@alumni.petra.ac.id
   - <handle>@google.com
   - <handle>@yahoo.com
   - + 1 of: <handle>@john.petra.ac.id OR <handle>@peter.petra.ac.id OR <handle>@petra.petra.ac.id

5) Output files:
   - 03-users.generated.ldif         (for ldapadd)
   - 05-revert-100.generated.ldif    (for ldapmodify delete)

Run:
  python3 gen_ldap_entities_100_v2.py \
    --out ldif/03-users.generated.ldif \
    --revert-out ldif/05-revert-100.generated.ldif \
    --start 20000 \
    --password 'SeongJinWoo999!'

Then populate:
  ldapadd -x -H ldap://127.0.0.1:389 -D "cn=admin,dc=petra,dc=ac,dc=id" -w "<ADMIN_PASSWORD>" -f ldif/03-users.generated.ldif

Revert:
  ldapmodify -x -H ldap://127.0.0.1:389 -D "cn=admin,dc=petra,dc=ac,dc=id" -w "<ADMIN_PASSWORD>" -f ldif/05-revert-100.generated.ldif
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import os
import random
import re
import uuid
from datetime import datetime
from typing import Iterable


BASE_DN = "dc=petra,dc=ac,dc=id"
PEOPLE_DN = f"ou=people,{BASE_DN}"

OU_DNS = {
    "students": f"ou=students,{PEOPLE_DN}",
    "staff": f"ou=staff,{PEOPLE_DN}",
    "alumni": f"ou=alumni,{PEOPLE_DN}",
    "external": f"ou=external,{PEOPLE_DN}",
}

MAIL_SUBDOMAINS = ["john", "peter", "petra"]  # -> <sub>.petra.ac.id

# 50 Indonesian human names (2 words)
HUMAN_FULLNAMES: list[str] = [
    "Aditya Pratama","Bima Saputra","Cahya Wibowo","Dimas Setiawan","Eka Santoso",
    "Farhan Hidayat","Gilang Nugroho","Hana Putri","Iqbal Ramadhan","Jihan Permata",
    "Kurniawan Siregar","Laila Anggraini","Made Wirawan","Nabila Maharani","Oka Prasetyo",
    "Putri Lestari","Raisa Octaviani","Satria Gunawan","Tania Kartika","Utami Sari",
    "Vito Mahendra","Wulan Purnama","Yusuf Kurnia","Zahra Aulia","Bagas Wijaya",
    "Chandra Surya","Dara Amelia","Elang Prakoso","Fadli Saputro","Gita Puspita",
    "Hendra Firmansyah","Indra Kusuma","Jelita Damayanti","Kevin Hartono","Luthfi Prabowo",
    "Mita Anindya","Nanda Pramana","Olin Nirmala","Prita Wulandari","Rangga Pamungkas",
    "Sinta Marcellina","Taufik Akbar","Umar Fadillah","Vania Safitri","Wahyu Hapsari",
    "Yohana Kristina","Zaki Firmanto","Arga Prameswara","Bella Candrawati","Citra Permadi",
]

# 50 non-human 2-word names (company/division/product-style)
NONHUMAN_NAMES: list[str] = [
    "Nova Dynamics","Atlas Forge","Quantum Harbor","Pixel Foundry","Garuda Systems",
    "Ember Studio","Aurora Ventures","Nimbus Works","Prism Logistics","Kencana Mart",
    "Sagara Foods","Merapi Digital","Bintang Fabric","Cakra Motors","Lentera Labs",
    "Nusantara Cloud","Arunika Media","Tirta Supply","Rajawali Cargo","Samudra Tech",
    "Pertiwi Energy","Seruni Pharma","Pelangi Retail","Borneo Trading","Bali Botanics",
    "Sulawesi Mining","Sumatra Agro","Jawa Textiles","Kalimantan Timber","Komodo Travel",
    "Mentari Finance","Langit Telecom","Rimba Outfitters","Batu Brew","Kopi Corner",
    "Sate Station","Roti Republic","Ayam Avenue","Teh Terrace","Nasi Network",
    "Hydro Pulse","Solar Crescent","Titan Fabrication","Orbit Appliance","Zenith Analytics",
    "Vertex Security","Cedar Capital","Marble Atelier","Oceanic Portfolio","Crystal District",
]


def split_two_words(full: str) -> tuple[str, str]:
    parts = full.strip().split()
    if len(parts) < 2:
        return (parts[0], parts[0])
    return (parts[0], " ".join(parts[1:]))


def slugify(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", ".", s)
    s = re.sub(r"\.+", ".", s).strip(".")
    return s


def ssha_hash(password: str) -> str:
    """Generate OpenLDAP-compatible {SSHA} (SHA1 + salt)."""
    salt = os.urandom(4)
    sha1 = hashlib.sha1(password.encode("utf-8") + salt).digest()
    return "{SSHA}" + base64.b64encode(sha1 + salt).decode("ascii")


def b64_ldif_value(value: str) -> str:
    """Return base64-encoded value for LDIF double-colon style."""
    return base64.b64encode(value.encode("utf-8")).decode("ascii")


def build_mail(local_part: str) -> str:
    sub = random.choice(MAIL_SUBDOMAINS)
    return f"{local_part}@{sub}.petra.ac.id"


def build_mail_alternates(handle: str) -> list[str]:
    # MUST ALWAYS contain these 4 values (order fixed for predictability)
    alt_sub = random.choice(MAIL_SUBDOMAINS)
    return [
        f"{handle}@alumni.petra.ac.id",
        f"{handle}@google.com",
        f"{handle}@yahoo.com",
        f"{handle}@{alt_sub}.petra.ac.id",
    ]


def ldif_entry(
    dn: str,
    uid: str,
    cn: str,
    sn: str,
    given_name: str,
    display_name: str,
    mail: str,
    alt_mails: list[str],
    petra_uuid: str,
    affiliation: str,
    status: str,
    user_password_plain: str,
    student_number: str | None = None,
) -> str:
    # userPassword written like your sample: userPassword:: <base64>
    pw_hash = ssha_hash(user_password_plain)
    pw_b64 = b64_ldif_value(pw_hash)

    lines: list[str] = [
        f"dn: {dn}",
        "objectClass: inetOrgPerson",
        "objectClass: petraPerson",
        f"uid: {uid}",
        f"cn: {cn}",
        f"sn: {sn}",
        f"givenName: {given_name}",
        f"displayName: {display_name}",
        f"mail: {mail}",
    ]

    for a in alt_mails:
        lines.append(f"mailAlternateAddress: {a}")

    lines += [
        f"petraUUID: {petra_uuid}",
        f"petraAffiliation: {affiliation}",
        f"petraAccountStatus: {status}",
    ]

    if student_number:
        lines.append(f"studentNumber: {student_number}")

    lines.append(f"userPassword:: {pw_b64}")
    lines.append("")  # entry separator
    return "\n".join(lines)


def delete_ldif(dns: Iterable[str], comment: str) -> str:
    ts = datetime.now().isoformat(timespec="seconds")
    out = [f"# {comment}", f"# Generated: {ts}", "#"]
    seen: set[str] = set()
    for dn in dns:
        if dn in seen:
            continue
        seen.add(dn)
        out += [f"dn: {dn}", "changetype: delete", ""]
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260216)
    ap.add_argument("--start", type=int, default=20000, help="numeric start for uid u-<8digits>")
    ap.add_argument("--password", type=str, default="SeongJinWoo999!", help="plain password to hash into userPassword")
    ap.add_argument("--out", type=str, default="03-users.generated.ldif", help="output LDIF for ldapadd")
    ap.add_argument("--revert-out", type=str, default="05-revert-100.generated.ldif", help="output LDIF for ldapmodify delete")
    args = ap.parse_args()

    random.seed(args.seed)

    if len(HUMAN_FULLNAMES) != 50 or len(NONHUMAN_NAMES) != 50:
        raise SystemExit("Name lists must be exactly 50 each.")

    # account status (random but biased like before)
    statuses = (["active"] * 80) + (["disabled"] * 10) + (["suspended"] * 10)
    random.shuffle(statuses)
    sidx = 0

    # placement plan:
    # - humans spread: students=30, staff=12, alumni=6, external=2
    # - non-human: external=50
    human_plan = (["students"] * 30) + (["staff"] * 12) + (["alumni"] * 6) + (["external"] * 2)
    nonhuman_plan = (["external"] * 50)

    entries: list[str] = []
    dns: list[str] = []

    uid_num = args.start

    # Humans
    for full, ou_key in zip(HUMAN_FULLNAMES, human_plan):
        given, sn = split_two_words(full)
        cn = f"{given} {sn}"
        uid = f"u-{uid_num:08d}"
        dn = f"uid={uid},{OU_DNS[ou_key]}"

        # mail local part: givenName (lower). If you want unique, switch to: f\"{given.lower()}.{uid}\"
        mail_local = slugify(given)
        mail = build_mail(mail_local)

        handle = slugify(f"{given}.{sn}")
        alt_mails = build_mail_alternates(handle)

        affiliation = {"students": "student", "staff": "staff", "alumni": "alumni", "external": "external"}[ou_key]

        student_number = None
        if ou_key == "students":
            # 10 digits like 5023123456 (5023 + 6 digits)
            student_number = "5023" + f"{random.randint(0, 999999):06d}"

        status = statuses[sidx]
        sidx += 1

        entries.append(ldif_entry(
            dn=dn,
            uid=uid,
            cn=cn,
            sn=sn,
            given_name=given,
            display_name=cn,
            mail=mail,
            alt_mails=alt_mails,
            petra_uuid=str(uuid.uuid4()),
            affiliation=affiliation,
            status=status,
            user_password_plain=args.password,
            student_number=student_number,
        ))
        dns.append(dn)
        uid_num += 1

    # Non-human (still using inetOrgPerson so Keycloak mapper stays consistent)
    for name, ou_key in zip(NONHUMAN_NAMES, nonhuman_plan):
        given, sn = split_two_words(name)
        cn = f"{given} {sn}"
        uid = f"u-{uid_num:08d}"
        dn = f"uid={uid},{OU_DNS[ou_key]}"

        mail_local = slugify(given)
        mail = build_mail(mail_local)

        handle = slugify(f"{given}.{sn}")
        alt_mails = build_mail_alternates(handle)

        status = statuses[sidx]
        sidx += 1

        entries.append(ldif_entry(
            dn=dn,
            uid=uid,
            cn=cn,
            sn=sn,
            given_name=given,
            display_name=cn,
            mail=mail,
            alt_mails=alt_mails,
            petra_uuid=str(uuid.uuid4()),
            affiliation="external",
            status=status,
            user_password_plain=args.password,
            student_number=None,
        ))
        dns.append(dn)
        uid_num += 1

    ts = datetime.now().isoformat(timespec="seconds")
    header = "\n".join([
        "# 03-users.generated.ldif",
        f"# Generated: {ts}",
        f"# Base DN: {BASE_DN}",
        "# Entities: 100 (50 human, 50 non-human)",
        "# mail domains: john.petra.ac.id / peter.petra.ac.id / petra.petra.ac.id (random)",
        "# mailAlternateAddress ALWAYS includes: alumni.petra.ac.id + google.com + yahoo.com + one-of john/peter/petra.petra.ac.id",
        "#",
    ])

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(header + "\n" + "\n".join(entries))

    with open(args.revert_out, "w", encoding="utf-8") as f:
        f.write(delete_ldif(dns, comment="05-revert-100.generated.ldif (DELETE the 100 generated entities)"))

    print(f"OK: wrote {args.out} and {args.revert_out}")
    print(f"UID range: u-{args.start:08d} .. u-{(uid_num-1):08d}")


if __name__ == "__main__":
    main()
